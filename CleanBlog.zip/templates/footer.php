<footer class="d-flex flex-wrap justify-content-center align-items-center py-3 my-4 border-top">
    <div class="container d-flex justify-content-center align-items-center">
        <a href="/" class="text-white mb-3 me-2 mb-md-0 text-decoration-none lh-1">
            CLEANBLOG
        </a>
        <span class="text-white mb-3 mb-md-0">© 2022 Company, Inc | Repin</span>
    </div>
</footer>